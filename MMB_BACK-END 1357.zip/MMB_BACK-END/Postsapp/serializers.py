from .models import Posts, Images
from rest_framework import serializers

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Posts
        fields = '__all__'
        
#postapp       
class MypostsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Posts
        fields = ["id","title","description","major_id","image_src",'created_time']
#postapp        
class MyimagesSerializer(serializers.ModelSerializer):        
    class Meta:
        model = Images
        fields = ["src"]