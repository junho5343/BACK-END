from django.shortcuts import render, redirect, get_object_or_404
# from .forms import PostForm, ImagesForm
from .models import Posts, Images
from django.utils import timezone
from rest_framework import viewsets
from django.views.decorators.csrf import csrf_exempt
from .serializers import PostSerializer, MypostsSerializer, MyimagesSerializer
from rest_framework.views import APIView

def home(request):
    return render(request, 'Postsapp/index.html')

def detail(request):
    post_detail = get_object_or_404(Posts, pk=post_id)
    return render(request, detail.html, {'post':post_detail})
    
# def upload(request):
#     form=PostForm()
#     imageform=ImagesForm()
#     return render(request, 'Postsapp/upload.html',{'form':form,'imageform':imageform})

class PostsViewSet(viewsets.ModelViewSet):
    queryset=Posts.objects.all();
    serializer_class=PostSerializer
    
@csrf_exempt 
def create(request):
    if request.method=="POST":
        post = Posts()
        post.title = request.POST['title']
        post.body = request.POST['body']
        post.date = timezone.now()
        post.image = request.FILES['image']
        post.save()
        for img in request.FILES.getlist('imgs'):
            # Photo 객체를 하나 생성한다.
            photo = Images()
            # 외래키로 현재 생성한 Post의 기본키를 참조한다.
            photo.post = post
            # imgs로부터 가져온 이미지 파일 하나를 저장한다.
            photo.image = img
            # 데이터베이스에 저장
            photo.save()
        return redirect('Postsapp/detail/'+str(post.id),{'post':post})
    else:
        post = Posts()
        return render(request,'Postsapp/create.html',{'post':post})
    
class MypostsView(APIView):
    def get(self, request):
        myposts = Posts.objects.all()       
        serialized_myposts = MypostsSerializer(myposts, many=True)
        return Response(data=serialized_myposts.data)

class MyimagesView(APIView):
    def get(self, request):        
        myimages = Images.objects.all()
        serialized_images = MyimagesSerializer(myimages, many=True)
        return Response(data=serialized_images.data)