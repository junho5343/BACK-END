from django.urls import path
from Postsapp import views 

from django.conf import settings
from django.conf.urls.static import static

app_name='Postsapp'
urlpatterns=[
    path('create/',views.create, name="create"),
    path('myposts/',views.MypostsView.as_view(), name='myposts'),
    path('myimages/',views.MyimagesView.as_view(), name='myimages'),
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
