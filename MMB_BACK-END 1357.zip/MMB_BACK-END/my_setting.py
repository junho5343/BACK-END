
SECRET_KEY = 'z7_loqfmp)_8+f*=5dp@rk6o+wy$8u1&7%%x!&_i6oi%g6mi_1'

DATABASES = {
    'default':{
        'ENGINE':'django.db.backends.mysql',
        'NAME':'mu',
        'USER':'root',
        'PASSWORD':'0001',
        'HOST':'localhost',
        'PORT':'3306',
    }
}


NAVER_EMAIL = 'mumubo0712@naver.com'
NAVER_PASSWORD = 'ananfqh0712'
NAVER_SMTP = "smtp.naver.com"
NAVER_SMTP_PORT = 587