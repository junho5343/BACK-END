from django.urls import path
from . import views

app_name='Commentsapp'
urlpatterns = [
    path('mycomments/',views.mycommentsViews.as_view(), name='mycomments'),
]