from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Comments
from .serializers import CommentsSerializer

class mycommentsViews(APIView):
    def get(self, request):
        mycomments = Comments.objects.all()
        serialized_mycomments = CommentsSerializer(mycomments, many=True)
        return Response(data=serialized_mycomments.data)