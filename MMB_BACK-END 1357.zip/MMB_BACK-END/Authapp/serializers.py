from rest_framework import serializers
from .models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=('major_id')
        

#authapp
class MypageSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["nickname", "major_id", "point"]